﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLib
{
    public enum QTYPE { MCQ=0, FIB=1, TF=2 }
    public enum MCQOption { A,B,C,D }

    public class Question
    {
        public int qid { get; set; }
        public QTYPE qt { get; set; }
        public string q { get; set; }
        public object ca { get; set; }

        public string a { get; set; }
        public string b { get; set; }
        public string c { get; set; }
        public string d { get; set; }

        public Question ()
        {
        }

        public Question(int qid, QTYPE qt, string q, object ca, string a = null, string b = null, string c = null, string d = null)
        {
            this.qid = qid;
            this.qt = qt;
            this.q = q;
            this.ca = ca;
            if (qt == QTYPE.MCQ)
            {
                this.a = a;
                this.b = b;
                this.c = c;
                this.d = d;
            }
        }   
    }
}
