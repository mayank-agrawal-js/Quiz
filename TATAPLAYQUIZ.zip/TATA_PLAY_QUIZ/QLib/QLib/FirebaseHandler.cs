﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FireSharp;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace QLib
{
    public class FirebaseHandler
    {
        private static readonly string DB_URL = "https://tp-tataplayquiz-db-default-rtdb.firebaseio.com/";
        private IFirebaseConfig config = new FirebaseConfig()
        {
            BasePath = DB_URL,
            AuthSecret = "8LdXy2fpfQBqqfQTjJGxg51WHLdDo5r7crVCyZA3"
        };
        private IFirebaseClient client;

        public FirebaseHandler()
        {
        }

        public string InitiateConnection()
        {
            try
            {
                client = new FirebaseClient(config);
            }
            catch
            {
                return "Please check your internet connection";
            }
            return "";
        }

        public List<Question> ReadQuestions() {
            List<Question> list = new();
            int i = 0;
            while (i < 5)
            {
                FirebaseResponse response = client.Get($"QROOT/q{i+1}/");
                Question q = response.ResultAs<Question>();
                list.Add(q);
                i++;
            }
       
            return list;
        }

        public bool WriteQuestion(Question q)
        {
            bool s = false;
            client.Update<Question>($"QROOT/q{q.qid}/", q);
            s = true;
            return s;
        }

    }
}
