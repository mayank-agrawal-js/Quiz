﻿using System;
using QLib;
using FireSharp;

namespace LibTest
{
    public class Program
    {
        public static void Main(string[]args)
        {
            m();
        }
        static void m()
        {
            string msg = "DATA LOADED";
            FirebaseHandler handler = new();
            Console.WriteLine(msg);
            Question q1 = new(1, QTYPE.FIB, "abcde_g", 'f');
            Question q2 = new(2, QTYPE.TF, "22 > 60", false);
            Question q3 = new(3, QTYPE.TF, "(100-{400+4}) < 0", true);
            Question q4 = new(4, QTYPE.MCQ, "HOW MANY LETTERS IN ALPHABET", MCQOption.B, "12", "26", "55", "30");
            Question q5 = new(5, QTYPE.MCQ, "What is our car name", MCQOption.D, "AURA", "I20", "I10", "CRETA");
            handler.WriteQuestion(q1);
            handler.WriteQuestion(q2);
            handler.WriteQuestion(q3);
            handler.WriteQuestion(q4);
            handler.WriteQuestion(q5);
            List<Question> questions = handler.ReadQuestions();
            int i = 0;
            while (i < questions.Count)
            {
                Question q = questions[i];
                Console.WriteLine($"{q.qid}, {q.q}, {q.qt}, {q.ca}, {q.a}, {q.b}, {q.c}, {q.d}");
                i++;
            }
        }
    }
}