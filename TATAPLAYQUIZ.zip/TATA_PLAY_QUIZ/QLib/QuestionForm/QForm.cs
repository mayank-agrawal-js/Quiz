﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLib;

namespace QuestionForm
{
    public partial class QForm : Form
    {
        public QForm()
        {
            InitializeComponent();
            qid.Text = "1";
        }

        private void QForm_FormClosing(object sender, FormClosingEventArgs e) {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                DialogResult d = MessageBox.Show("Are you sure you want to exit?", "Question Form", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (d == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        private void qt_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (qt.SelectedIndex)
            {
                case 0:
                    mcqCa.Visible = true;
                    fibCa.Visible = false;
                    tfCa.Visible = false;
                    mcqCa.SelectedIndex = 0;
                    Size = new(1048, 250);
                    break;
                case 1:
                    mcqCa.Visible = false;
                    fibCa.Visible = true;
                    tfCa.Visible = false;
                    fibCa.Text = "Answer here...";
                    Size = new(517, 250);
                    break;
                case 2:
                    mcqCa.Visible = false;
                    fibCa.Visible = false;
                    tfCa.Visible = true;
                    tfCa.SelectedIndex = 0;
                    Size = new(517, 250);
                    break;
                default:
                    break;
            }
        }

        private void writeQuestion_Click(object sender, EventArgs e)
        {
            FirebaseHandler handler = new FirebaseHandler();
            string connectionResult = handler.InitiateConnection();
            if (connectionResult != "")
            {
                MessageBox.Show(connectionResult, "Question Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            int _qid = Convert.ToInt32(qid.Text);
            QTYPE _qt = (QTYPE)qt.SelectedIndex;
            string _q = q.Text;
            object _ca = _qt switch
            {
                QTYPE.MCQ => (MCQOption)mcqCa.SelectedIndex,
                QTYPE.FIB => fibCa.Text,
                QTYPE.TF => tfCa.SelectedIndex == 0 ? true: false,
                _ => throw new NotImplementedException()
            };
            string _a, _b, _c, _d;
            Question question = new Question();
            if (_qt == QTYPE.MCQ)
            {
                _a = (a.Text).ToString();
                _b = (b.Text).ToString();
                _c = (c.Text).ToString();
                _d = (d.Text).ToString();
                question = new Question(_qid, _qt, _q, _ca, _a, _b, _c, _d);
            } else
            {
                question = new Question(_qid, _qt, _q, _ca);
            }

            if (handler.WriteQuestion(question))
            {
                MessageBox.Show($"Inserted Question {question.qid} Successfully", "Question Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (_qid < 5) 
            {
                qid.Text = (_qid + 1).ToString();
                q.Text = "";
                qt.SelectedIndex = -1;
                mcqCa.SelectedIndex = -1;
                tfCa.SelectedIndex = -1;
                fibCa.Text = "";
                a.Text = "";
                b.Text = "";
                c.Text = "";
                d.Text = "";
                q.Select();
            } else if (_qid == 5)
            {
                MessageBox.Show("All questions inserted. Goodbye!", "Question Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Thread.Sleep(2000);
                Environment.Exit(0);
            }
        }
    }
}
