﻿namespace QuestionForm
{
    partial class QForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.qid = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.q = new System.Windows.Forms.TextBox();
            this.qt = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.fibCa = new System.Windows.Forms.TextBox();
            this.mcqCa = new System.Windows.Forms.ComboBox();
            this.tfCa = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.a = new System.Windows.Forms.TextBox();
            this.b = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.c = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.d = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.writeQuestion = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Q. ID";
            // 
            // qid
            // 
            this.qid.AutoSize = true;
            this.qid.Location = new System.Drawing.Point(42, 77);
            this.qid.Name = "qid";
            this.qid.Size = new System.Drawing.Size(17, 20);
            this.qid.TabIndex = 1;
            this.qid.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(90, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Question";
            // 
            // q
            // 
            this.q.Location = new System.Drawing.Point(90, 80);
            this.q.Name = "q";
            this.q.Size = new System.Drawing.Size(125, 27);
            this.q.TabIndex = 3;
            // 
            // qt
            // 
            this.qt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.qt.FormattingEnabled = true;
            this.qt.Items.AddRange(new object[] {
            "MCQ",
            "Fill the blank",
            "True False"});
            this.qt.Location = new System.Drawing.Point(221, 80);
            this.qt.Name = "qt";
            this.qt.Size = new System.Drawing.Size(125, 28);
            this.qt.TabIndex = 4;
            this.qt.SelectedIndexChanged += new System.EventHandler(this.qt_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(221, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Question Type";
            // 
            // fibCa
            // 
            this.fibCa.Location = new System.Drawing.Point(352, 80);
            this.fibCa.Name = "fibCa";
            this.fibCa.Size = new System.Drawing.Size(125, 27);
            this.fibCa.TabIndex = 6;
            // 
            // mcqCa
            // 
            this.mcqCa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.mcqCa.FormattingEnabled = true;
            this.mcqCa.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D"});
            this.mcqCa.Location = new System.Drawing.Point(352, 80);
            this.mcqCa.Name = "mcqCa";
            this.mcqCa.Size = new System.Drawing.Size(125, 28);
            this.mcqCa.TabIndex = 8;
            // 
            // tfCa
            // 
            this.tfCa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tfCa.FormattingEnabled = true;
            this.tfCa.Items.AddRange(new object[] {
            "True",
            "False"});
            this.tfCa.Location = new System.Drawing.Point(352, 80);
            this.tfCa.Name = "tfCa";
            this.tfCa.Size = new System.Drawing.Size(125, 28);
            this.tfCa.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(352, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Correct Answer";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(499, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Option A";
            // 
            // a
            // 
            this.a.Location = new System.Drawing.Point(499, 81);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(125, 27);
            this.a.TabIndex = 12;
            // 
            // b
            // 
            this.b.Location = new System.Drawing.Point(630, 81);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(125, 27);
            this.b.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(630, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 20);
            this.label6.TabIndex = 13;
            this.label6.Text = "Option B";
            // 
            // c
            // 
            this.c.Location = new System.Drawing.Point(759, 81);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(125, 27);
            this.c.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(759, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 20);
            this.label7.TabIndex = 15;
            this.label7.Text = "Option C";
            // 
            // d
            // 
            this.d.Location = new System.Drawing.Point(890, 81);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(125, 27);
            this.d.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(890, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 20);
            this.label8.TabIndex = 17;
            this.label8.Text = "Option D";
            // 
            // writeQuestion
            // 
            this.writeQuestion.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.writeQuestion.Location = new System.Drawing.Point(42, 136);
            this.writeQuestion.Name = "writeQuestion";
            this.writeQuestion.Size = new System.Drawing.Size(435, 43);
            this.writeQuestion.TabIndex = 19;
            this.writeQuestion.Text = "Add Question";
            this.writeQuestion.UseVisualStyleBackColor = true;
            this.writeQuestion.Click += new System.EventHandler(this.writeQuestion_Click);
            // 
            // QForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(499, 203);
            this.Controls.Add(this.writeQuestion);
            this.Controls.Add(this.d);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.c);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.b);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.a);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tfCa);
            this.Controls.Add(this.mcqCa);
            this.Controls.Add(this.fibCa);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.qt);
            this.Controls.Add(this.q);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.qid);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "QForm";
            this.Text = "QForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.QForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label qid;
        private Label label2;
        private TextBox q;
        private ComboBox qt;
        private Label label3;
        private TextBox fibCa;
        private ComboBox mcqCa;
        private ComboBox tfCa;
        private Label label4;
        private Label label5;
        private TextBox a;
        private TextBox b;
        private Label label6;
        private TextBox c;
        private Label label7;
        private TextBox d;
        private Label label8;
        private Button writeQuestion;
    }
}