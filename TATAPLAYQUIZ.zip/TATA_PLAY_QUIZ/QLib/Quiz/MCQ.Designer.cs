﻿namespace Quiz
{
    partial class MCQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.qid = new System.Windows.Forms.Label();
            this.q = new System.Windows.Forms.Label();
            this.a = new System.Windows.Forms.Button();
            this.b = new System.Windows.Forms.Button();
            this.c = new System.Windows.Forms.Button();
            this.d = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // qid
            // 
            this.qid.AutoSize = true;
            this.qid.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.qid.Location = new System.Drawing.Point(12, 9);
            this.qid.Name = "qid";
            this.qid.Size = new System.Drawing.Size(64, 41);
            this.qid.TabIndex = 3;
            this.qid.Text = "Q1.";
            // 
            // q
            // 
            this.q.AutoSize = true;
            this.q.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.q.Location = new System.Drawing.Point(82, 9);
            this.q.Name = "q";
            this.q.Size = new System.Drawing.Size(279, 41);
            this.q.TabIndex = 2;
            this.q.Text = "Example Question...";
            // 
            // a
            // 
            this.a.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.a.Location = new System.Drawing.Point(12, 53);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(329, 140);
            this.a.TabIndex = 4;
            this.a.Text = "A) ";
            this.a.UseVisualStyleBackColor = true;
            this.a.Click += new System.EventHandler(this.a_Click);
            // 
            // b
            // 
            this.b.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.b.Location = new System.Drawing.Point(347, 53);
            this.b.Name = "b";
            this.b.Size = new System.Drawing.Size(329, 140);
            this.b.TabIndex = 5;
            this.b.Text = "B) ";
            this.b.UseVisualStyleBackColor = true;
            this.b.Click += new System.EventHandler(this.b_Click);
            // 
            // c
            // 
            this.c.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.c.Location = new System.Drawing.Point(12, 199);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(329, 127);
            this.c.TabIndex = 6;
            this.c.Text = "C) ";
            this.c.UseVisualStyleBackColor = true;
            this.c.Click += new System.EventHandler(this.c_Click);
            // 
            // d
            // 
            this.d.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.d.Location = new System.Drawing.Point(347, 199);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(329, 127);
            this.d.TabIndex = 7;
            this.d.Text = "D) ";
            this.d.UseVisualStyleBackColor = true;
            this.d.Click += new System.EventHandler(this.d_Click);
            // 
            // MCQ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 338);
            this.Controls.Add(this.d);
            this.Controls.Add(this.c);
            this.Controls.Add(this.b);
            this.Controls.Add(this.a);
            this.Controls.Add(this.qid);
            this.Controls.Add(this.q);
            this.Name = "MCQ";
            this.Text = "MCQ";
            this.Load += new System.EventHandler(this.MCQ_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label qid;
        private Label q;
        private Button a;
        private Button b;
        private Button c;
        private Button d;
    }
}