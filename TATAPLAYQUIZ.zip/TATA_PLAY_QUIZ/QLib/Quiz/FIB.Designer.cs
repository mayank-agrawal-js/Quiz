﻿namespace Quiz
{
    partial class FIB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.qid = new System.Windows.Forms.Label();
            this.q = new System.Windows.Forms.Label();
            this.ans = new System.Windows.Forms.TextBox();
            this.submit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // qid
            // 
            this.qid.AutoSize = true;
            this.qid.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.qid.Location = new System.Drawing.Point(12, 9);
            this.qid.Name = "qid";
            this.qid.Size = new System.Drawing.Size(64, 41);
            this.qid.TabIndex = 3;
            this.qid.Text = "Q1.";
            // 
            // q
            // 
            this.q.AutoSize = true;
            this.q.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.q.Location = new System.Drawing.Point(82, 9);
            this.q.Name = "q";
            this.q.Size = new System.Drawing.Size(279, 41);
            this.q.TabIndex = 2;
            this.q.Text = "Example Question...";
            // 
            // ans
            // 
            this.ans.Location = new System.Drawing.Point(12, 53);
            this.ans.Multiline = true;
            this.ans.Name = "ans";
            this.ans.Size = new System.Drawing.Size(658, 78);
            this.ans.TabIndex = 4;
            // 
            // submit
            // 
            this.submit.Font = new System.Drawing.Font("Segoe UI", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.submit.Location = new System.Drawing.Point(12, 137);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(658, 162);
            this.submit.TabIndex = 5;
            this.submit.Text = "Submit answer";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // FIB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 311);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.ans);
            this.Controls.Add(this.qid);
            this.Controls.Add(this.q);
            this.Name = "FIB";
            this.Text = "FIB";
            this.Load += new System.EventHandler(this.FIB_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label qid;
        private Label q;
        private TextBox ans;
        private Button submit;
    }
}