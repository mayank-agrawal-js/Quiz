﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLib;

// TODO: Test App without Quiz.Utils.QUtils;
// Manually write switch statements.
// Did it work? 
// Future Darsh: 

namespace Quiz
{
    public partial class WelcomeForm : Form
    {
        public static List<Question> questions;
        public WelcomeForm()
        {
            InitializeComponent();
        }
        private void WelcomeForm_Load(object sender, EventArgs e)
        {
            FirebaseHandler firebaseHandler = new FirebaseHandler();
            firebaseHandler.InitiateConnection();
            questions = firebaseHandler.ReadQuestions();
        }

        private void proceed_Click(object sender, EventArgs e)
        {
            Hide();
            Question q = new Question();
            switch (q.qt)
            {
                case QTYPE.MCQ:
                    new MCQ(1).ShowDialog();
                    break;
                case QTYPE.FIB:
                    new FIB(1).ShowDialog();
                    break;
                case QTYPE.TF:
                    new TF(1).ShowDialog();
                    break;
                default:
                    break;
            }
            Close();
        }
    }
}
