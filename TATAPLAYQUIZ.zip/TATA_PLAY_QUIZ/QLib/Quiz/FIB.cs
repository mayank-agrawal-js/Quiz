﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLib;

// IDEA: RESULTS, PERCENTAGE CORRECT, Logging into text file

namespace Quiz
{
    public partial class FIB : Form
    {
        Question question;
        int _qid;
        public FIB(int qid)
        {
            InitializeComponent();
            this._qid = qid;
            question = WelcomeForm.questions[_qid - 1];
        }

        private void FIB_Load(object sender, EventArgs e)
        {
            qid.Text = $"Q{_qid}.";
            q.Text = question.q;
        }

        private void submit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(ans.Text))
            {
                string f_str = ans.Text.ToLower().Trim();
                string f_ca = question.ca.ToString().ToLower().Trim();
                if (f_str == f_ca)
                {
                    MessageBox.Show("Correct Answer!!!", "Quiz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                } else
                {
                    MessageBox.Show($"Wrong answer.\nThe correct answer was {question.ca}");
                }
                Hide();
                if (_qid < 5)
                {
                    Question _q = WelcomeForm.questions[_qid];
                    switch (_q.qt)
                    {
                        case QTYPE.MCQ:
                            new MCQ(_q.qid).ShowDialog();
                            break;
                        case QTYPE.FIB:
                            new FIB(_q.qid).ShowDialog();
                            break;
                        case QTYPE.TF:
                            new TF(_q.qid).ShowDialog();
                            break;
                        default:
                            break;
                    }
                } else
                {
                    MessageBox.Show("The quiz is complete! Bye!", "Quiz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Environment.Exit(0);
                }
                Close();
            }
        }
    }
}
