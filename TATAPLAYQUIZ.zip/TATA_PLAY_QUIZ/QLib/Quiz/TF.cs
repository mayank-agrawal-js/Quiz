﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLib;

namespace Quiz
{
    public partial class TF : Form
    {
        Question question;
        int _qid;
        public TF(int _qid)
        {
            InitializeComponent();
            this._qid = _qid;
            question = WelcomeForm.questions[_qid - 1];
        }

        private void TF_Load(object sender, EventArgs e)
        {
            qid.Text = $"Q{_qid}.";
            q.Text = question.q;
        }

        private void btnFalse_Click(object sender, EventArgs e)
        {
            if (!Convert.ToBoolean(question.ca))
            {
                MessageBox.Show("Correct Answer!!!", "Quiz", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"Wrong answer.\nThe correct answer was {Convert.ToBoolean(question.ca)}");
            }
            Hide();
            if (_qid < 5)
            {
                Question _q = WelcomeForm.questions[_qid];
                switch (_q.qt)
                {
                    case QTYPE.MCQ:
                        new MCQ(_q.qid).ShowDialog();
                        break;
                    case QTYPE.FIB:
                        new FIB(_q.qid).ShowDialog();
                        break;
                    case QTYPE.TF:
                        new TF(_q.qid).ShowDialog();
                        break;
                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("The quiz is complete! Bye!", "Quiz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Environment.Exit(0);
            }
            Close();
        }

        private void btnTrue_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(question.ca))
            {
                MessageBox.Show("Correct Answer!!!", "Quiz", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"Wrong answer.\nThe correct answer was {Convert.ToBoolean(question.ca)}");
            }
            Hide();
            Question q = WelcomeForm.questions[_qid];
            switch (q.qt)
            {
                case QTYPE.MCQ:
                    new MCQ(q.qid).ShowDialog();
                    break;
                case QTYPE.FIB:
                    new FIB(q.qid).ShowDialog();
                    break;
                case QTYPE.TF:
                    new TF(q.qid).ShowDialog();
                    break;
                default:
                    break;
            }
            Close();
        }
    }
}
