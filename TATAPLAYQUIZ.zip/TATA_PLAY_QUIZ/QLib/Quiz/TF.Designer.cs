﻿namespace Quiz
{
    partial class TF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.q = new System.Windows.Forms.Label();
            this.qid = new System.Windows.Forms.Label();
            this.btnTrue = new System.Windows.Forms.Button();
            this.btnFalse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // q
            // 
            this.q.AutoSize = true;
            this.q.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.q.Location = new System.Drawing.Point(82, 9);
            this.q.Name = "q";
            this.q.Size = new System.Drawing.Size(279, 41);
            this.q.TabIndex = 0;
            this.q.Text = "Example Question...";
            // 
            // qid
            // 
            this.qid.AutoSize = true;
            this.qid.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.qid.Location = new System.Drawing.Point(12, 9);
            this.qid.Name = "qid";
            this.qid.Size = new System.Drawing.Size(64, 41);
            this.qid.TabIndex = 1;
            this.qid.Text = "Q1.";
            // 
            // btnTrue
            // 
            this.btnTrue.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnTrue.Location = new System.Drawing.Point(12, 60);
            this.btnTrue.Name = "btnTrue";
            this.btnTrue.Size = new System.Drawing.Size(326, 239);
            this.btnTrue.TabIndex = 2;
            this.btnTrue.Text = "True";
            this.btnTrue.UseVisualStyleBackColor = true;
            this.btnTrue.Click += new System.EventHandler(this.btnTrue_Click);
            // 
            // btnFalse
            // 
            this.btnFalse.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnFalse.Location = new System.Drawing.Point(344, 60);
            this.btnFalse.Name = "btnFalse";
            this.btnFalse.Size = new System.Drawing.Size(326, 239);
            this.btnFalse.TabIndex = 3;
            this.btnFalse.Text = "False";
            this.btnFalse.UseVisualStyleBackColor = true;
            this.btnFalse.Click += new System.EventHandler(this.btnFalse_Click);
            // 
            // TF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 311);
            this.Controls.Add(this.btnFalse);
            this.Controls.Add(this.btnTrue);
            this.Controls.Add(this.qid);
            this.Controls.Add(this.q);
            this.Name = "TF";
            this.Text = "TF";
            this.Load += new System.EventHandler(this.TF_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label q;
        private Label qid;
        private Button btnTrue;
        private Button btnFalse;
    }
}